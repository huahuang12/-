package com.hh.response;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 返回对象包装类（带泛型）
 *
 * @author huahuang
 * @create 2022-02-08 10:06
 */
@Data
@NoArgsConstructor
public class ResultBean<T> implements Serializable {
    /**
     * 操作是否成功
     */
    private boolean success;
    /**
     * 操作代码
     */
    private int code;
    /**
     * 提示信息
     */
    private String message;

    private String url;

    /**
     * 异常时间
     */
    private String date;

    /**
     * 总条数
     */
    private long count = 0;

    /**
     * 返回的数据
     */
    private T data;


    //已知异常自定义消息（500/404等）
    public ResultBean(ResultCode resultCode, String message) {
        setResultCode(resultCode);
        this.message = message;
    }

    // 封装数据，默认封装resultCode。SUCCESS
    public ResultBean(T t) {
        setResultCode(ResultCode.SUCCESS);
        this.data = t;
    }

    // 封页封装
    public ResultBean(T lists, long total) {
        setResultCode(ResultCode.SUCCESS);
        this.data = lists;
        this.count = total;
    }

    // 封装未知异常
    public ResultBean(Throwable e) {
        setResultCode(ResultCode.UNKNOWN_EXCEPTION);
        this.message = e.getMessage();
    }

    private void setResultCode(ResultCode resultCode) {
        this.success = resultCode.success;
        this.code = resultCode.code;
        this.message = resultCode.message;
        this.date = LocalDateTime.now().toString();
    }
}
